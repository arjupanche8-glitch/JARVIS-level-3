package com.jarvis.level3

import android.app.Activity
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.content.Intent
import android.widget.*
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var tts: TextToSpeech
    private lateinit var chat: TextView
    private val prefs by lazy { getSharedPreferences("jarvis_memory", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24,24,24,24)
        }
        val title = TextView(this).apply {
            text = "🤖 JARVIS"
            textSize = 30f
            setPadding(0,0,0,16)
        }
        chat = TextView(this).apply {
            textSize = 17f
            text = prefs.getString("chat", "JARVIS: Namaste! Main aapka assistant hoon.\n") ?: ""
        }
        val input = EditText(this).apply { hint = "JARVIS ko message likho..." }
        val send = Button(this).apply { text = "Send" }
        val voice = Button(this).apply { text = "🎙️ Voice" }

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(send, LinearLayout.LayoutParams(0, -2, 1f))
            addView(voice, LinearLayout.LayoutParams(0, -2, 1f))
        }
        root.addView(title)
        root.addView(ScrollView(this).apply { addView(chat) }, LinearLayout.LayoutParams(-1,0,1f))
        root.addView(input)
        root.addView(row)
        setContentView(root)

        send.setOnClickListener {
            val q = input.text.toString().trim()
            if (q.isNotEmpty()) { respond(q); input.text.clear() }
        }
        voice.setOnClickListener {
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            i.putExtra(RecognizerIntent.EXTRA_PROMPT, "Boliye...")
            startActivityForResult(i, 10)
        }
    }

    private fun respond(q: String) {
        val answer = when {
            q.contains("hello", true) || q.contains("namaste", true) -> "Namaste! Main JARVIS hoon. Aapki kya help karun?"
            q.contains("naam") -> "Mera naam JARVIS hai."
            q.contains("time", true) || q.contains("samay", true) -> "Abhi " + java.text.SimpleDateFormat("hh:mm a", Locale.getDefault()).format(java.util.Date()) + " hai."
            else -> "Maine aapki baat save kar li hai. Real AI answers ke liye AI API/server connect karna hoga."
        }
        chat.text = chat.text.toString() + "\nYou: $q\nJARVIS: $answer\n"
        prefs.edit().putString("chat", chat.text.toString()).apply()
        tts.speak(answer, TextToSpeech.QUEUE_FLUSH, null, "jarvis")
    }

    override fun onActivityResult(requestCode:Int, resultCode:Int, data:Intent?) {
        super.onActivityResult(requestCode,resultCode,data)
        if (requestCode == 10 && resultCode == RESULT_OK) {
            val s = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!s.isNullOrBlank()) respond(s)
        }
    }
    override fun onInit(status:Int) {
        if (status == TextToSpeech.SUCCESS) tts.language = Locale("hi","IN")
    }
    override fun onDestroy() { tts.shutdown(); super.onDestroy() }
}
