# Architecture

Phone
  |
  +-- Voice input / Wake word
  |
  +-- Android foreground service
  |
  +-- Tool/permission router
  |
  +--> Secure JARVIS backend
          |
          +-- AI model
          +-- Long-term memory
          +-- Web/tool calls
          +-- Safety/permission checks
          |
          +--> Response
  |
  +-- Text-to-Speech

Sensitive actions must require Android permissions and, where appropriate, explicit user confirmation.
