from fastapi import FastAPI
from pydantic import BaseModel
from datetime import datetime

app = FastAPI(title="JARVIS Level 3")

# Development memory store. Production: SQLite/PostgreSQL.
MEMORY = {}

class ChatRequest(BaseModel):
    user_id: str
    message: str

class MemoryRequest(BaseModel):
    user_id: str
    text: str

@app.get("/health")
def health():
    return {"ok": True, "jarvis": "online"}

@app.post("/memory")
def save_memory(req: MemoryRequest):
    MEMORY.setdefault(req.user_id, []).append({
        "text": req.text,
        "time": datetime.utcnow().isoformat()
    })
    return {"saved": True}

@app.get("/memory/{user_id}")
def get_memory(user_id: str):
    return {"items": MEMORY.get(user_id, [])}

@app.post("/chat")
def chat(req: ChatRequest):
    # Replace this section with the chosen AI provider SDK/API.
    # Secret credentials stay on the server, never in the Android APK.
    history = MEMORY.get(req.user_id, [])
    reply = (
        "JARVIS online. AI provider connector is ready to be configured. "
        f"You said: {req.message}"
    )
    return {
        "reply": reply,
        "memory_items_available": len(history)
    }

@app.post("/tool")
def tool(name: str):
    # Central permission-aware tool router.
    allowed = {"web_search", "calculator", "open_app", "reminder"}
    return {"tool": name, "allowed": name in allowed}
