package com.jarvis

import android.app.*
import android.content.Intent
import android.os.IBinder
import androidx.core.app.NotificationCompat

class JarvisService : Service() {
    override fun onCreate() {
        super.onCreate()
        val channelId = "jarvis_voice"
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(channelId, "JARVIS Voice", NotificationManager.IMPORTANCE_LOW)
        )
        val notification = NotificationCompat.Builder(this, channelId)
            .setContentTitle("JARVIS Active")
            .setContentText("Voice assistant is running")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .build()
        startForeground(9001, notification)

        // Modules wired here:
        // 1 Voice input
        // 2 Wake-word engine
        // 3 Backend/AI request
        // 4 Memory/tool router
        // 5 TTS response
        // 6 Permissioned Android actions
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY
    override fun onBind(intent: Intent?): IBinder? = null
}
