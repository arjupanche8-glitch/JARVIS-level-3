package com.jarvis

/*
 JARVIS Level 3 module contracts.

 WakeWordEngine: detects a user-selected wake phrase.
 SpeechEngine: speech-to-text.
 BrainClient: sends text to secure backend.
 MemoryClient: reads/writes long-term memory.
 ToolRouter: asks for/uses only permitted Android actions.
 TtsEngine: speaks the final response.

 These interfaces keep the app modular so each production engine can be swapped
 without rewriting the whole assistant.
*/
interface WakeWordEngine { fun start(); fun stop() }
interface SpeechEngine { fun start(); fun stop() }
interface BrainClient { suspend fun ask(text: String): String }
interface MemoryClient { suspend fun save(text: String); suspend fun recent(): List<String> }
interface ToolRouter { fun allowedActions(): List<String> }
interface TtsEngine { fun speak(text: String); fun stop() }
