# JARVIS Level 3 — ALL IN ONE

यह एक ही project है जिसमें Level-3 के सभी 8 modules एक साथ रखे गए हैं:

1. AI Brain connector
2. Voice conversation
3. Wake-word ("Hey Jarvis") integration point
4. Long-term memory
5. Internet/tool router
6. Text-to-Speech
7. Android foreground/background service foundation
8. Permission-based Android actions

## जरूरी सच्चाई
यह source project है, तैयार APK नहीं। Real AI के लिए server-side API key चाहिए। API key APK या GitHub में नहीं डालनी है।
Android background microphone और phone automation Android की permissions/security restrictions के अधीन हैं।

## Structure
- android/  -> Android app
- backend/  -> AI + memory + tools server
- web/      -> phone/browser test interface
- docs/     -> architecture

## Run order
1. Backend server configure करें.
2. Android app में backend URL set करें.
3. Android microphone permission दें.
4. Voice/AI modules test करें.
5. Wake word और device actions को explicit permissions के साथ enable करें.

## अगले production steps
- वास्तविक AI provider implementation
- SQLite/PostgreSQL memory
- secure authentication
- production wake-word engine
- Android accessibility/device APIs only where permitted
